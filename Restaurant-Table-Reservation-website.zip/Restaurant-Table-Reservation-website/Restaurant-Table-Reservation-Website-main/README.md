# Restaurant Table Reservation Website

The restaurant table reservation website allows the user to book a table at a particular restaurant. The frontend of the website is done using HTML, CSS and some javascript code for scrolling effect. The backend is done using SQL database from xampp and for connecting the frontend to the database, PHP is used. 

The key features of this website are that it works as an advertisement for the restaurant with reviews, images, menu display and the booking section. In the booking section the user has to give his details like name, number, email and has to select the date, time slot and number of people for whom the table has to be reserved.

